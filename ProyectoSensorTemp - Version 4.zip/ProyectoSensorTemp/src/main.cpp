//******************************************/
// BE3029 - Electronica Digital 2
// Proyecto 1 - Sensor de Temperatura 
// MCU: ESP32 dev kit 1.0
//******************************************/

//******************************************/
// Librerias
//******************************************/
#include <Arduino.h>
#include <stdint.h>
#include "display7.h"


//******************************************/
// Definiciones
//******************************************/
#define display1 1
#define display2 22
#define display3 23

#define ledbajo 14
#define ledmedio 26
#define ledalto 33

#define canalledbajo 0
#define canalledmedio 1
#define canalledalto 2
#define canalservo 3

#define sensortemp 32
#define boton 15

#define servo 12

//******************************************/
// Prototipos de funciones
//******************************************/

void moverServo(int angulo);
void mostrarDisplay(float temp);
//******************************************/
// Variables globales
//******************************************/
int lectura = 0;
float temperatura = 0.0;
float ultimaTemperatura = 0.0; // valor inicial

unsigned long tiempoAnterior = 0;
const long debounceDelay = 50; // intervalo de 50 ms
bool botonPresionado = LOW;

//******************************************/
// ISRs Rutinas de Interrupcion
//******************************************/
//******************************************/
// Configuracion
//******************************************/
void setup() {
    
    Serial.begin(115200);

    pinMode(display1, OUTPUT);
    pinMode(display2, OUTPUT);
    pinMode(display3, OUTPUT);

    digitalWrite(display1, LOW);
    digitalWrite(display2, LOW);
    digitalWrite(display3, LOW);

    ledcSetup(canalledbajo, 500, 8); // canal 0, 500 Hz, resolucion 8 bits
    ledcSetup(canalledmedio, 500, 8); // canal 1,
    ledcSetup(canalledalto, 500, 8); // canal 2,

    ledcAttachPin(ledbajo, canalledbajo);
    ledcAttachPin(ledmedio, canalledmedio);
    ledcAttachPin(ledalto, canalledalto);

    pinMode(sensortemp, INPUT);
    pinMode(boton, INPUT_PULLDOWN);

    ledcSetup(canalservo, 50, 16); // canal 3, 50 Hz, resolucion 16 bits
    ledcAttachPin(servo, canalservo);

    analogReadResolution(12); // resolución de 0-4095
    analogSetPinAttenuation(sensortemp, ADC_11db);

    configdisplay(); // configurar display de 7 segmentos

    moverServo(0); // mover servo a 0 grados al inicio

}
//******************************************/
// Loop Principal
//******************************************/
void loop() {
    bool botonActual = digitalRead(boton);
    if (botonActual == HIGH && botonPresionado == LOW && (millis() - tiempoAnterior > debounceDelay)) {
        // botón presionado
        tiempoAnterior = millis();

        // leer ADC del LM35
        lectura = analogRead(sensortemp);

        // calcular temperatura
        float voltaje = (lectura * 3.3 ) / 4095; // trabajando en 5v
        temperatura = (voltaje * 100) + 3; // LM35 da 10mV por grado, 100 para convertir a grados con ligero ajuste para calibrar
        ultimaTemperatura = temperatura; // actualizar ultima temperatura medida

        // imprimir por serial
        Serial.print("Temperatura: ");
        Serial.print(ultimaTemperatura, 1);
        Serial.println(" °C");

        // lógica de LEDs con PWM
        if (ultimaTemperatura < 22.0) {
            ledcWrite(canalledbajo, 255);  // LED bajo encendido
            ledcWrite(canalledmedio, 0);
            ledcWrite(canalledalto, 0);
            moverServo(45); // mover servo a 45 grados
        }
        else if (ultimaTemperatura >= 22.0 && temperatura < 25.0) {
            ledcWrite(canalledbajo, 0);
            ledcWrite(canalledmedio, 255); // LED medio encendido
            ledcWrite(canalledalto, 0);
            moverServo(90); // mover servo a 90 grados
        }
        else { // temperatura >= 25
            ledcWrite(canalledbajo, 0);
            ledcWrite(canalledmedio, 0);
            ledcWrite(canalledalto, 255);  // LED alto encendido
            moverServo(135); // mover servo a 135 grados
        }

        
    }

    botonPresionado = botonActual;

    mostrarDisplay(ultimaTemperatura); // mostrar temperatura en display de 7 segmentos
}
//******************************************/
// Otras funciones
//******************************************/
void moverServo(int angulo) {

    // ángulo entre 0 y 180
    int ciclomin = 1638; // 1 ms (65535 * 0.001 / 0.02)
    int ciclomax = 8192; // 2 ms (65535 * 0.002 / 0.02)

    // mapear ángulo a ciclo de trabajo (duty cycle)
    int duty = map(angulo, 0, 180, ciclomin, ciclomax); // 1ms a 2ms en resolución de 16 bits
    ledcWrite(canalservo, duty);
}

void mostrarDisplay(float temp) {

    int valor = (int)(temp*10); //volver temperatura a entero (1 decimal)
    
    int decena = (valor / 100) % 10; //numero en primer display
    int unidad = (valor / 10) % 10; //numero en segundo display
    int decimal = valor % 10; // numero en tercer display

    // Mostrar centenas
    digitalWrite(display1, HIGH);
    digitalWrite(display2, LOW);
    digitalWrite(display3, LOW);
    desplegarnumero(decena);
    desplegarpunto(0); // desactivar punto decimal
    delay(5);

    // Mostrar decenas
    digitalWrite(display1, LOW);
    digitalWrite(display2, HIGH);
    digitalWrite(display3, LOW);
    desplegarnumero(unidad);
    desplegarpunto(1); // punto decimal siempre activo en segundo display
    delay(5);

    // Mostrar unidades con punto decimal
    digitalWrite(display1, LOW);
    digitalWrite(display2, LOW);
    digitalWrite(display3, HIGH);
    desplegarnumero(decimal);
    desplegarpunto(0); // desactivar punto decimal
    delay(5);
}