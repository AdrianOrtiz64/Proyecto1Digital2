#ifndef __DISPLAY7_H__
#define __DISPLAY7_H__

//inclusion de librerias necesarias
#include <Arduino.h>
#include <stdint.h>

#define dA 21
#define dB 13
#define dC 5
#define dD 16
#define dE 3
#define dF 18
#define dG 19
#define dP 17 // Pin para el punto decimal 

//prototipos de funciones
//Funcion para configurar el display de 7 segmentos
void configdisplay(void);

//desplegar numero en el display de 7 segmentos
void desplegarnumero(uint8_t num);

//desplegar punto decimal en el display de 7 segmentos (1 para activar, 0 para desactivar)
void desplegarpunto(uint8_t punto);

#endif // __DISPLAY7_H__