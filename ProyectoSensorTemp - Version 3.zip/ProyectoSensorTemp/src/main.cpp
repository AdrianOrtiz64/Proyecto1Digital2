//******************************************/
// BE3029 - Electronica Digital 2
// Proyecto 1 - Sensor de Temperatura 
// MCU: ESP32 dev kit 1.0
//******************************************/

//******************************************/
// Librerias
//******************************************/
#include <Arduino.h>
#include <stdint.h>
#include "display7.h"


//******************************************/
// Definiciones
//******************************************/
#define display1 1
#define display2 22
#define display3 23

#define ledbajo 14
#define ledmedio 26
#define ledalto 33

#define canalledbajo 0
#define canalledmedio 1
#define canalledalto 2
#define canalservo 3

#define sensortemp 35
#define boton 36

#define servo 12

//******************************************/
// Prototipos de funciones
//******************************************/

void moverServo(int angulo);
//******************************************/
// Variables globales
//******************************************/
int lectura = 0;
float temperatura = 0.0;
//******************************************/
// ISRs Rutinas de Interrupcion
//******************************************/
//******************************************/
// Configuracion
//******************************************/
void setup() {
    //configurar transistores para display

    Serial.begin(115200);
    pinMode(display1, OUTPUT);
    pinMode(display2, OUTPUT);
    pinMode(display3, OUTPUT);

    digitalWrite(display1, LOW);
    digitalWrite(display2, LOW);
    digitalWrite(display3, LOW);

    ledcSetup(canalledbajo, 5000, 8); // canal 0, 5k Hz, resolucion 8 bits
    ledcSetup(canalledmedio, 5000, 8); // canal 1,
    ledcSetup(canalledalto, 5000, 8); // canal 2,

    ledcAttachPin(ledbajo, canalledbajo);
    ledcAttachPin(ledmedio, canalledmedio);
    ledcAttachPin(ledalto, canalledalto);

    pinMode(sensortemp, INPUT);
    pinMode(boton, INPUT_PULLDOWN);

    ledcSetup(canalservo, 50, 16); // canal 3, 50 Hz, resolucion 16 bits
    ledcAttachPin(servo, canalservo);

    analogReadResolution(12); // resolución de 0-4095
    analogSetPinAttenuation(sensortemp, ADC_11db); // ~3.3V rango máximo

}
//******************************************/
// Loop Principal
//******************************************/
void loop() {
    if (digitalRead(boton) == HIGH) {

        // leer ADC del LM35
        lectura = analogRead(sensortemp);

        // calcular temperatura
        float voltaje = (lectura / 4095.0) * 3.3; // usando atenuacion 11dB (~3.3V rango)
        temperatura = voltaje / 0.010; // 10mV por grado

        // imprimir por serial
        Serial.print("Temperatura: ");
        Serial.print(temperatura, 1);
        Serial.println(" °C");

        // lógica de LEDs con PWM
        if (temperatura < 22.0) {
            ledcWrite(canalledbajo, 255);  // LED bajo encendido
            ledcWrite(canalledmedio, 0);
            ledcWrite(canalledalto, 0);
            moverServo(45); // mover servo a 45 grados
        }
        else if (temperatura >= 22.0 && temperatura < 25.0) {
            ledcWrite(canalledbajo, 0);
            ledcWrite(canalledmedio, 255); // LED medio encendido
            ledcWrite(canalledalto, 0);
            moverServo(90); // mover servo a 90 grados
        }
        else { // temperatura >= 25
            ledcWrite(canalledbajo, 0);
            ledcWrite(canalledmedio, 0);
            ledcWrite(canalledalto, 255);  // LED alto encendido
            moverServo(135); // mover servo a 135 grados
        }

        delay(500); // pequeña pausa para evitar lecturas demasiado rápidas
    }

    
}
//******************************************/
// Otras funciones
//******************************************/
void moverServo(int angulo) {

    // ángulo entre 0 y 180
    int ciclomin = 1638; // 1 ms (65535 * 0.001 / 0.02)
    int ciclomax = 8192; // 2 ms (65535 * 0.002 / 0.02)

    // mapear ángulo a ciclo de trabajo (duty cycle)
    int duty = map(angulo, 0, 180, ciclomin, ciclomax); // 1ms a 2ms en resolución de 16 bits
    ledcWrite(canalservo, duty);
}
