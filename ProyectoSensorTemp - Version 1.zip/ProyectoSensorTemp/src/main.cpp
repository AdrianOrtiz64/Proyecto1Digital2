PROYECTO SENSOR TEMP - PARTE 1


//******************************************/
// BE3029 - Electronica Digital 2
// Proyecto 1 - Sensor de Temperatura 
// MCU: ESP32 dev kit 1.0
//******************************************/

//******************************************/
// Librerias
//******************************************/
#include <Arduino.h>
#include <stdint.h>
#include "display7.h"


//******************************************/
// Definiciones
//******************************************/
#define display1 1
#define display2 22
#define display3 23

#define ledbajo 14
#define ledmedio 26
#define ledalto 33

#define sensortemp 35
#define boton 36

#define servo 12

//******************************************/
// Prototipos de funciones
//******************************************/
//******************************************/
// Variables globales
//******************************************/
int lectura = 0;
float temperatura = 0.0;
//******************************************/
// ISRs Rutinas de Interrupcion
//******************************************/
//******************************************/
// Configuracion
//******************************************/
void setup() {
    //configurar transistores para display

    Serial.begin(115200);
    pinMode(display1, OUTPUT);
    pinMode(display2, OUTPUT);
    pinMode(display3, OUTPUT);

    digitalWrite(display1, LOW);
    digitalWrite(display2, LOW);
    digitalWrite(display3, LOW);

    pinMode(ledbajo, OUTPUT);
    pinMode(ledmedio, OUTPUT);
    pinMode(ledalto, OUTPUT);

    digitalWrite(ledbajo, LOW);
    digitalWrite(ledmedio, LOW);
    digitalWrite(ledalto, LOW);

    pinMode(sensortemp, INPUT);
    pinMode(boton, INPUT);

    analogReadResolution(12); // resolución de 0-4095
    analogSetPinAttenuation(sensortemp, ADC_6db); // ~2.2V rango máximo




    //encender display de 7 segmentos
    digitalWrite(display1, HIGH);
    desplegarnumero(3);
    desplegarpunto(0);
    delay(1000); //esperar 1 segundo
    //esto solo envia un valor al display especifico

}
//******************************************/
// Loop Principal
//******************************************/
void loop() {
    // leer boton (activo en HIGH)
    if (digitalRead(boton) == HIGH) {
        // leer ADC del LM35
        lectura = analogRead(sensortemp);

        // convertir a voltaje
        float voltaje = (lectura / 4095.0) * 2.2; // usando atenuacion 6dB (2.2V rango)
        
        // calcular temperatura
        temperatura = voltaje / 0.010; // 10mV por grado

        // imprimir por serial
        Serial.print("Temperatura: ");
        Serial.print(temperatura, 1);
        Serial.println(" °C");

    }

    
}
//******************************************/
// Otras funciones
//******************************************/